
# Code Review

## Page 1 Playground
![image](https://github.com/user-attachments/assets/b7a23f42-75b0-4f07-ac16-986e316e13fc)
![image](https://github.com/user-attachments/assets/1bfad3ca-6937-4db6-a0e2-c8dfebf0da77)
![image](https://github.com/user-attachments/assets/fedcb4d1-e1fc-42e6-ae9e-0fe3af93cd3b)

The playground page provides an overview of the data. There are three filters that you can play with to get the key metric data. There is a supporting visualization showing the trends and location hierarchy based on the filters.

## Page 2 General History
![](./images/code_review/p2-2.png)
![](./images/code_review/p2-3.png)
![](./images/code_review/p2-4.png)

This dashboard provides a historical timeline of crime and weather trends in Chicago, allowing users to easily see specific mountains and dips in the data through the date range, crime type, and weather patterns across 25 years. Moving forward, I want to highlight more well-known social events in history—like crime during the holidays, the pandemic, and the 2008 recession—to see how these moments shaped what we see in the data. I’d also love to dive deeper into how certain crimes behave across months and observe which ones are more likely to occur during specific times of the year. To further connect weather and crime, I’m interested in exploring the months when environmental conditions seem to have the strongest influence on crime patterns. I think there’s still a lot of room to explore the data, and I’m excited to building visuals that further interesting insights.

## Page 3 Crime Map

A brief introduction to this page:

![](./images/code_review/page3_intro.png)

- This page is a Chicago Safety Navigation System. First we predict the safety level for each district based on the given inputs: weekday, month, temperature, etc. Safety Level: 10 - percentile(qcut predicted_crimes). 
- The model has been trained by Random Forest and saved to an AWS S3 bucket (public, so everyone can access it). 
- The we provide the 'Safety Path' that take both distance and safety level into consideration. Specifically, we use Dijkstra but set the edge weight to be distance*(11-safety_level). That way, we provide a path that do a balance between shortest path and safety. Click 'Get Your Safety Path!' button to get you safety path!
- By the first time, it may take ~5min to load. To speed up, we applied caching strategies that can cache the loaded map up to 2 hours. Therefore the subsequent access will be fast.

- This page is not yet complete. Certain features are currently being developed. (i.e., Currently it can only do prediction based on [hours, weekday, month]. We're trying to combine one more dataset so it could do prediction based on [humidity, temperature])

## Page 4 Weather & Crime

![](./images/code_review/page4_intro.png)

The page makes use of an additional dataset describing the Chicago weather. The comparison of both datasets allows the user to explore the seasonality of crime and how the weather can influence the prevalence of crimes in Chicago. 
