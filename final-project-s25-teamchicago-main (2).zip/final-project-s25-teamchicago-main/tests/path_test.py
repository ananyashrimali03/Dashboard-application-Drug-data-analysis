import os
import sys

TEST_DIR = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, os.path.dirname(TEST_DIR))

from utils.path import get_path_from_project_root

path = get_path_from_project_root("utils", "path.py")
print(path)
