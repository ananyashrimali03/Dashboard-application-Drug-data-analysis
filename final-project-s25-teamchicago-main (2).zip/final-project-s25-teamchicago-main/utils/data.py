import pandas as pd
import numpy as np
from sodapy import Socrata
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
import joblib
import geopandas as gpd
from shapely.geometry import Point
import streamlit as st

from utils.path import get_path_from_project_root


@st.cache_data(ttl=7200, show_spinner=True) # cache ttl = 2h
def get_data_gdf_with_zipcode(verbose=False):
    client = Socrata("data.cityofchicago.org", None)
    results = client.get("ijzp-q8t2", limit=100000, order="date DESC")
    df = pd.DataFrame.from_records(results)

    if verbose:
        print(df.head(10))

    df = df.dropna(subset=['date', 'latitude', 'longitude'])
    df['date'] = pd.to_datetime(df['date'])
    df['date_only'] = df['date'].dt.date
    df['hour'] = df['date'].dt.hour
    df['weekday'] = df['date'].dt.weekday 
    df['month'] = df['date'].dt.month

    chicago_zipcodes = gpd.read_file("https://data.cityofchicago.org/api/geospatial/unjd-c2ca?method=export&format=GeoJSON")
    gdf = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df.longitude, df.latitude), crs=chicago_zipcodes.crs)
    gdf = gpd.sjoin(gdf, chicago_zipcodes[['zip', 'geometry']], how="left", predicate="within")
    gdf = gdf.dropna(subset=["zip"])
    gdf['zip'] = gdf['zip'].astype(str)

    WEATHER_DATA_PATH = get_path_from_project_root("data_clean", "weather_data.csv")
    weather_df = pd.read_csv(WEATHER_DATA_PATH)
    weather_df['date_only'] = pd.to_datetime(weather_df['YEAR'].astype(str) + '-' + 
                                            weather_df['MO'].astype(str).str.zfill(2) + '-' + 
                                            weather_df['DY'].astype(str).str.zfill(2)).dt.date

    weather_features = weather_df[['date_only', 'T2M', 'RH2M']]

    gdf = gdf.merge(weather_features, on='date_only', how='left')
    gdf = gdf.dropna(subset=['T2M', 'RH2M'])

    if verbose:
        print(gdf.head(10))

    return gdf

@st.cache_data(ttl=7200, show_spinner=True) # cache ttl = 2h
def get_data_df_without_zipcode(verbose=False):
    client = Socrata("data.cityofchicago.org", None)
    results = client.get("ijzp-q8t2", limit=100000, order="date DESC")
    df = pd.DataFrame.from_records(results)

    if verbose:
        print(df.head(10))

    df = df.dropna(subset=['date', 'latitude', 'longitude'])
    df['date'] = pd.to_datetime(df['date'])
    df['date_only'] = df['date'].dt.date
    df['hour'] = df['date'].dt.hour
    df['weekday'] = df['date'].dt.weekday 
    df['month'] = df['date'].dt.month

    WEATHER_DATA_PATH = get_path_from_project_root("data_clean", "weather_data.csv")
    weather_df = pd.read_csv(WEATHER_DATA_PATH)
    weather_df['date_only'] = pd.to_datetime(weather_df['YEAR'].astype(str) + '-' + 
                                            weather_df['MO'].astype(str).str.zfill(2) + '-' + 
                                            weather_df['DY'].astype(str).str.zfill(2)).dt.date

    weather_features = weather_df[['date_only', 'T2M', 'RH2M', 'PRECTOTCORR', 'WS10M', 'PS']]

    df_merged = df.merge(weather_features, on='date_only', how='left')
    df_merged = df_merged.dropna(subset=['T2M', 'RH2M', 'PRECTOTCORR', 'WS10M', 'PS'])

    if verbose:
        print(df_merged.head(10))

    return df_merged



if __name__ == "__main__":
    # use case
    get_data_gdf_with_zipcode(verbose=True)
    get_data_df_without_zipcode(verbose=True)
