import streamlit as st
import pandas as pd

import geopandas as gpd
import networkx as nx
import requests

import folium
from streamlit_folium import folium_static

import osmnx as ox
import os

from utils.path import get_path_from_project_root
from utils.prediction import prediction
from utils.data import get_data_df_without_zipcode

# download model from AWS S3 bucket
def load_prediction_model():
    local_model_path = get_path_from_project_root("model", "crime_model.pkl")
    local_encoder_path = get_path_from_project_root("model", "zipcode_encoder.pkl")

    model_url = "https://bucket-ml-ids.s3.amazonaws.com/crime_model.pkl"
    encoder_url = "https://bucket-ml-ids.s3.amazonaws.com/zipcode_encoder.pkl"

    os.makedirs(get_path_from_project_root("model"), exist_ok=True)

    if not os.path.exists(local_model_path):
        r = requests.get(model_url)
        with open(local_model_path, "wb") as f:
            f.write(r.content)

    if not os.path.exists(local_encoder_path):
        r = requests.get(encoder_url)
        with open(local_encoder_path, "wb") as f:
            f.write(r.content)

# return Chicago zipcode Dataframe (GeoDataFrame)
@st.cache_data
def load_chicago_zipcodes():
    url = "https://data.cityofchicago.org/api/geospatial/unjd-c2ca?method=export&format=GeoJSON"
    response = requests.get(url)
    chicago_zipcodes = gpd.read_file(response.text)
    # st.warning("Got the Chicago zipcode data successfully!")
    return chicago_zipcodes

# assign safety level for each zipcode (randomly for now)
# 1-10: dangerous-safe
@st.cache_data
def assign_safety_levels(_chicago_zipcodes, prediction_result):
    chicago_zipcodes = _chicago_zipcodes.copy()

    zip_to_safety = prediction_result.set_index('zip')['safety_level'].to_dict()

    # default safety level: 5
    chicago_zipcodes['safety_level'] = chicago_zipcodes['zip'].apply(
        lambda z: zip_to_safety.get(z, 5)
    )

    return chicago_zipcodes

# load chicago network graph (drive only)
@st.cache_data(show_spinner=True)
def load_chicago_network():
    try:
        G = ox.graph_from_place('Chicago, Illinois, USA', network_type='drive')
        return G
    except:
        st.error("fail to load chicago network graph.")
        return None

# get the safety level of a point based on the regions it be within
def _find_zipcode_for_point(point, chicago_zipcodes):
    point_gdf = gpd.GeoDataFrame(geometry=[point], crs=chicago_zipcodes.crs)
    joined = gpd.sjoin(point_gdf, chicago_zipcodes, how="left", predicate="within")
    if joined.empty or pd.isna(joined.iloc[0]['index_right']):
        # if the point is not within every zipcode, return the default security level.
        return 5
    else:
        return joined.iloc[0]['safety_level']

# modify edge weights based on safety
@st.cache_data(show_spinner=True)
def modify_edge_weights_based_on_safety(_G, _chicago_zipcodes):

    G = _G.copy()
    chicago_zipcodes = _chicago_zipcodes.copy()
    G_safe = G.copy()
    
    for u, v, k, data in G_safe.edges(data=True, keys=True):
        # get the midpoint of the edge
        if 'geometry' in data:
            mid_point = data['geometry'].interpolate(0.5, normalized=True)
        else:
            u_point = (G_safe.nodes[u]['y'], G_safe.nodes[u]['x'])
            v_point = (G_safe.nodes[v]['y'], G_safe.nodes[v]['x'])
            mid_point = ((u_point[0] + v_point[0])/2, (u_point[1] + v_point[1])/2)
            from shapely.geometry import Point
            mid_point = Point(mid_point[1], mid_point[0]) 
        
        safety_level = _find_zipcode_for_point(mid_point, chicago_zipcodes)
        
        length = data.get('length', 100)        
        safety_factor = 11 - safety_level  
        
        # get the new weight based on the safety & distance
        new_weight = length * safety_factor
        
        G_safe[u][v][k]['weight'] = new_weight
    
    return G_safe

@st.cache_data(show_spinner=True)
def calculate_safest_path(_G_safe, start_point, end_point):
    G_safe = _G_safe.copy()
    
    start_node = ox.distance.nearest_nodes(G_safe, X=start_point[1], Y=start_point[0])
    end_node = ox.distance.nearest_nodes(G_safe, X=end_point[1], Y=end_point[0])
    
    # by Dijkstra
    try:
        path = nx.shortest_path(G_safe, start_node, end_node, weight='weight')
        return path
    except nx.NetworkXNoPath:
        st.error("fail to find the path.")
        return None

def create_map(chicago_zipcodes, G, path=None, start_point=None, end_point=None):

    # Mapbox token (owner: Yuchen Wang)
    mapbox_token = "pk.eyJ1IjoiZWFzb253YW5nMTExIiwiYSI6ImNtOWF2cGlpbzBhNncya3EyaWM3OWNpNGIifQ.lhCf1jfzxVlqBio2ZjjocQ"

    m = folium.Map(
        location=[41.8781, -87.6298],  # longitude and latitude of Chicago
        zoom_start=11,
        tiles="cartodbpositron"
    )
    
    folium.TileLayer(
        tiles=f'https://api.mapbox.com/styles/v1/mapbox/streets-v11/tiles/{{z}}/{{x}}/{{y}}?access_token={mapbox_token}',
        attr='Mapbox',
        name='Mapbox Streets'
    ).add_to(m)
    
    folium.Choropleth(
        geo_data=chicago_zipcodes.__geo_interface__,
        name='Safety Levels',
        data=chicago_zipcodes,
        columns=['zip', 'safety_level'],
        key_on='feature.properties.zip',
        fill_color='YlGn', 
        fill_opacity=0.7,
        line_opacity=0.2,
        legend_name='Safety Level (1-10)(dangerous - safe)'
    ).add_to(m)

    if path and G:
        path_coords = []
        for node in path:
            y, x = G.nodes[node]['y'], G.nodes[node]['x']
            path_coords.append((y, x))
        
        folium.PolyLine(
            path_coords,
            color='blue',
            weight=5,
            opacity=0.8
        ).add_to(m)
    
    if start_point:
        folium.Marker(
            location=[start_point[0], start_point[1]],
            popup="Start",
            icon=folium.Icon(color='green', icon='play')
        ).add_to(m)
    
    if end_point:
        folium.Marker(
            location=[end_point[0], end_point[1]],
            popup="End",
            icon=folium.Icon(color='red', icon='stop')
        ).add_to(m)

    return m