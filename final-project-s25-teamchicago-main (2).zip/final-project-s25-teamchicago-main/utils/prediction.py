import pandas as pd
import joblib

from utils.path import get_path_from_project_root

def _check_legal(hour, weekday, month):
    if hour > 23 or hour < 0 or weekday > 7 or weekday < 1 or month > 12 or month < 1:
        return False
    else:
        return True

# predict the safety level based on the given inputs
# for page3: Crime Maps
def prediction(hour, weekday, month, temperature, humidity):
    assert _check_legal(hour, weekday, month), "illegal inputs!"

    model_path = get_path_from_project_root("model", "crime_model.pkl")
    le_path = get_path_from_project_root("model", "zipcode_encoder.pkl")

    model = joblib.load(model_path)
    le = joblib.load(le_path)

    zipcodes = le.classes_
    zip_encoded = le.transform(zipcodes)

    X_pred = pd.DataFrame({
        "zip_encoded": zip_encoded,
        "hour": hour,
        "weekday": weekday,
        "month": month,
        "T2M": temperature,
        "RH2M": humidity
    })

    predicted_crimes = model.predict(X_pred)

    percentile = pd.qcut(predicted_crimes, 10, labels=False)
    safety_level = 10 - percentile

    output = pd.DataFrame({
        "zip": zipcodes,
        "predicted_crimes": predicted_crimes,
        "safety_level": safety_level.astype(int)
    }).sort_values("safety_level")

    return output

if __name__ == "__main__":

    # use case
    result = prediction(
        hour=1,
        weekday=5,
        month=12,
        temperature= 96.5,
        humidity=-5.1
    )
    print(result.head(40))
