# Final Project Proposal

**GitHub Repo URL**: https://github.com/CMU-IDS-Spring-2025/final-project-s25-teamchicago

Team Members: Alexandra Slabakis, Ananya Shrimali, Enora Petry, Yuchen Wang

## Describe Chosen Dataset - Chicago Crime
Our team plans to use a Chicago Crime dataset (https://data.cityofchicago.org/stories/s/Crimes-2001-to-present-Dashboard/5cd6-ry5g), extracted from the Chicago Police Department’s Citizen Law Enforcement Analysis and Reporting (CLEAR) portal system. The dataset records all reported incidents of Chicago crimes, excluding murders, and includes precise details such as location, date, time, and crime type. Exploring the dataset can help us better identify and explore crime patterns across the city, identifying where and when different types of crimes occur. 

The dataset includes all reported incidents of Chicago crimes, from January 1, 2001 to the present, with updates excluding the most recent seven days (data currently updated to March 11, 2025). This long-term coverage allows our team to provide the most up-to-date assessment of Chicago crime and compare current crime trends in comparison to the past two decades. 

Since the data includes both location and time details, we can analyze crime trends by district to highlight areas with higher risks at specific times. Additionally, the dataset categorizes where crimes take place: on the street, in residence, or other locations. This location column within the dataset allows our team to filter for crimes that directly impact citizens versus those that occur in private settings. 

Our project aims to develop an interactive, data-driven crime risk analysis tool for the city of Chicago. By integrating historical crime data with supplementary weather data from another dataset, our team will explore potential correlations between crime rates and environmental conditions. Further, our team plans to use machine learning techniques and interactive data visualizations to identify crime patterns across times, locations, and weather conditions, ultimately providing a relevant solution for public safety. 

## How our team will access it - Chicago Crime Dataset

The dataset is incredibly maintained, making it easier for our team to download a .CSV file that is not only accurate, but fully documented. This data is free and publicly available through the Chicago Data Portal’s export feature and currently contains around 8.2 million rows. If our team has further questions about the dataset, such as the meaning behind column names, the catalog summary (https://data.cityofchicago.org/browse?sortBy=most_accessed&pageSize=20&page=1) data states that we are allowed to contact the Data Fulfillment and Analysis Division of the Chicago Police Department at DFA@ChicagoPolice.org.

The following are highlighted columns our team is interested in exploring :

- Date (Floating Timestamp): data when the incident occurred (estimated by the reporter)’
- Primary type (Text): the ICUR code of the incident
- Arrest (Boolean): indicates whether an arrest was made.
- Primary Type (Text): Dictates offense committed by the perp.
- Description (Text): Lists the written description of the perp’s offense.
- Community Area (Text): indicate the Community Area where the incident occurred. Chicago has 77 Community Areas: https://data.cityofchicago.org/d/cauq-8yn6 (longitude and latitude)
- Location Description (Text): Indicates the type of location where the crime was committed: apartment, street, drug store.
- Latitude and Longitude (Number): Exact geographic coordinates of the crime.
- Time of the Day: Allows filtering of crimes depending on time of the day.
- Domestic (Boolean): whether it is domestic or not. 

## Project Methodology:

- Data Processing and Cleaning
- EDA
- Predictive Modeling
- Dashboard for crime risk assessment

## Describe the data science question you hope to answer with your data
The data science question we aim to answer is: Which areas in Chicago pose the highest risk for pedestrians after midnight? 

This broader question entails a number of additional questions such as:
- In which district is crime more prevalent?
- How does time of the day influence the rate of crimes?
- How have crime patterns changed over the past two decades?
- How do seasons affect crime rates? (Summer versus Winter) 
- What types of crimes are most common at different times of the day? 

## Additional Dataset to Include

Chicago Weather Database (Extra Dataset. Tentative) 

https://www.kaggle.com/datasets/curiel/chicago-weather-database

Our dataset could be potentially enhanced if we try to include the weather dataset from NOAA or OpenWeatherMaps according to our project timeline. This can give additional context such as if the crime increases in bad weather or not. Weathering data of Chicago from Apr 2021 to Jan 2025. The dataset consists of multiple columns that capture different aspects of the data. 

Each column represents a specific attribute or feature of the dataset. 
- Temperature (Number): measured in degrees centigrade.
- Relative Humidity (Number): percentage.
- Wind Speed: average daily wind speed measured in meters per second (m/s)
- Time (Numbers): MO + DY + HR

Several studies have found that higher temperatures are associated with increased rates of certain types of crimes, especially violent crimes. So we believe this Dataset could be helpful for our prediction regarding the crime rate of Chicago Community Areas.


# Sketches and Data Analysis

## Pages

- Playground Page: Dashboard showing basic information of the two datasets.
    - Basic filters
    - Statistic charts
        - A bar chart for Location Description displayed horizontally
        - A bar chart for Theft Description displayed vertically
        - etc.
- General History with timeline
    - Trends what's coming down & coming up
        - A area chart with the frequency of the most frequent crimes
- Crime Maps
    - Date Range & Time Range Filter
    - Dangerosity of districts
    - Top 10 hotspot locations for crimes being committed
    - Trends of crimes - top 10Ge
- Weather & Crime Correlations
    - Detailed filters
    - Season maps - crime by winter/spring/summer/fall
    - Pattern of prominent crime locations during weather?
        - Ie: snowing a lot = lots of robberies in shadyside 
    - Trends of particular crimes - top 10 crimes

## Data Processing

>  Do you have to do substantial data cleanup? 

The dataset does not appear to require substantial data cleanup. The large majority of rows contains complete information.

Additionally, a few data fields contain categorical data such as type of crime and location descriptions. They contain a fixed number of options. For example, the location description has 60 different options, which can easily be aggregated.

The column for crime description will need additional cleaning as it contains additional information about the crime with no specific format. This column might be harder to use in our visualization dashboard.

> What quantities do you plan to derive from your data? 

Since our team has been working with two Chicago datasets, Crime and Weather, over the past 25 years, our team will explore potential correlations between crime rates and environmental conditions. Through customizable filters and interactive visualizations our team will identify crime patterns across times, locations, and weather conditions, ultimately providing a relevant solution for public safety. 

We envision a playground page, a dashboard showing basic information from the two datasets, allowing the audience to get to know the data and how it works. We plan to extract quantities from the calculated averages and medians of Chicago crime by theft and location, display the breakdown of theft and its distribution, and a historical display of percentage data that would detect anomalies and identify trends over time. These quantities will be manipulated by a date range filter as well as a filter that allows you to analyze this data by weather impact. By using bar charts, line graphs, scatter plots, and a location map, we plan to visualize broad insights that will help inform our detailed data analysis on weather and crime rate.

To gather more detail on Chicago’s crime and specific geographical insights, our team will build a crime page that illustrates the dangerousness of each district, identify the top 10 locations where crimes are frequently committed, and develop date-based trends that illustrate how crime rates fluctuate over time. This page will primarily be visualized with maps such as heatmaps and count maps to better understand the crime surrounding Chicago. 

Finally, our team will conduct an in-depth analysis on the correlation between weather and crime. Our team will analyze how crime varies by season, identify relationships between specific weather conditions such as high heat or snow and crime rates, as well as recognizing which crimes are most prevalent under certain weather conditions. Through the use of heatmaps, scatter plots, and line graphs, this page will allow users to explore the data in an engaging way.

> How will data processing be implemented? (Show some screenshots of your data to demonstrate you have explored it.)

1. Merge the weather dataset and the crime dataset based on the time stamp (hours)

    ![](./images/sketches/1.png)

    ![](./images/sketches/2.png)

2. Remove rows with missing geographic values.

    ![](./images/sketches/3.png)

3. Encode the nominal attributes for future prediction. (i.e., label encoding, one-hot, etc.)

    ![](./images/sketches/4.png)

## Exploratory Data Analysis

Code is available at our repo: https://github.com/CMU-IDS-Spring-2025/final-project-s25-teamchicago/blob/main/data_analysis/exploratory_data_analysis.ipynb

- Top 20 types of crime:

    ![](./images/sketches/5.png)

- Top 20 types of location for the crimes:

    ![](./images/sketches/6.png)

- The number of crimes per month:

    ![](./images/sketches/7.png)

- Location of crimes in 2025:

    ![](./images/sketches/8.png)

## System Design

> How will you display your data? 

The data could be displayed in the form of pages and dashboard. The dashboard could be developed using Streamlit for displaying crime trends and predictions. There could be interactive filters to explore various crime categories, weather conditions and location. 

> What types of interactions will you support? 

1.	Drop Down for exploring crime trends over time. 
2.	A map hover feature that can show detailed information about crime.
3.	A weather-based filter to understand and analyze how weather has impacted the different conditions. 
4.	Time slider
5.	Map hover features
6.	Data filters (weather, location, crime type)
7.	Comparisions 

> Provide some sketches that you have for the system design.

### Layout

![](./images/sketches/9.png)

Example Layout for the pages, done using Figma:

![](./images/sketches/10.png)

![](./images/sketches/11.png)

![](./images/sketches/12.png)

![](./images/sketches/13.png)


### Data Visualizations

![](./images/sketches/14.png)

![](./images/sketches/15.png)

![](./images/sketches/16.png)

![](./images/sketches/17.png)

![](./images/sketches/18.png)

![](./images/sketches/19.png)

![](./images/sketches/20.png)












