import streamlit as st
import pandas as pd
import numpy as np
import pydeck as pdk

from streamlit_folium import folium_static

from utils.prediction import prediction
from utils.data import get_data_df_without_zipcode

# key components of the map
from utils.navigation_map import (
    load_prediction_model,
    load_chicago_zipcodes,
    assign_safety_levels,
    load_chicago_network,
    modify_edge_weights_based_on_safety,
    calculate_safest_path,
    create_map,
)

def main():

    st.set_page_config(layout="wide", page_title="Chicago Safety Navigation System")

    st.title("Chicago Safety Navigation System")

    # ---- 3D Heatmap ---- #

    with st.container(border=True):

        st.subheader("Crime Counts 3D Heatmap Visualization")
        
        df = get_data_df_without_zipcode()

        df['latitude'] = pd.to_numeric(df['latitude'], errors='coerce')
        df['longitude'] = pd.to_numeric(df['longitude'], errors='coerce')
        df = df.dropna(subset=['latitude', 'longitude'])

        col1, col2 = st.columns([1,5])

        with col1:

            st.markdown("**Move the slider to filter the crime data:**")

            temperature_value = st.slider(
                "Filter by Temperature at 2 Meters (Centigrade):",
                int(df["T2M"].min()),
                int(df["T2M"].max()),
                (int(df["T2M"].min()), int(df["T2M"].max()))
            )

            humidity_value = st.slider(
                "Filter by Relative Humidity at 2 Meters (Percentage %):",
                int(df["RH2M"].min()),
                int(df["RH2M"].max()),
                (int(df["RH2M"].min()), int(df["RH2M"].max()))
            )

            precipitation_value = st.slider(
                "Filter by Precipitation (mm/day):",
                int(df["PRECTOTCORR"].min()),
                int(df["PRECTOTCORR"].max()),
                (int(df["PRECTOTCORR"].min()), int(df["PRECTOTCORR"].max()))
            )

            windspeed_value = st.slider(
                "Filter by Wind Speed at 10 Meters (m/s):",
                int(df["WS10M"].min()),
                int(df["WS10M"].max()),
                (int(df["WS10M"].min()), int(df["WS10M"].max()))
            )
            
            surfacepressure_value = st.slider(
                "Filter by Surface Pressure (kPa):",
                int(df["PS"].min()),
                int(df["PS"].max()),
                (int(df["PS"].min()), int(df["PS"].max()))
            )

            with st.container(border=True):
                st.markdown("This is a 3D heatmap to show crime distribution based on the weather inputs.")
                st.markdown("It's build by pydeck.")
                st.markdown("Hold `ctrl` to adjust the perspective.")

        with col2:
            filtered_df = df[
                (df["T2M"] >= temperature_value[0]) &
                (df["T2M"] <= temperature_value[1]) &
                (df["RH2M"] >= humidity_value[0]) &
                (df["RH2M"] <= humidity_value[1]) &
                (df["PRECTOTCORR"] >= precipitation_value[0]) &
                (df["PRECTOTCORR"] <= precipitation_value[1]) &
                (df["WS10M"] >= windspeed_value[0]) &
                (df["WS10M"] <= windspeed_value[1]) &
                (df["PS"] >= surfacepressure_value[0]) &
                (df["PS"] <= surfacepressure_value[1])
            ]

            data_for_pydeck = []
            for _, row in filtered_df.iterrows():
                lat = float(row['latitude'])
                lon = float(row['longitude'])        

                data_for_pydeck.append({
                    'latitude': lat,
                    'longitude': lon
                })


            view_state = pdk.ViewState(
                latitude=np.mean([d['latitude'] for d in data_for_pydeck]),
                longitude=np.mean([d['longitude'] for d in data_for_pydeck]),
                zoom=10,
                pitch=50,
                bearing=0
            )

            grid_layer = pdk.Layer(
                'GridLayer',
                data=data_for_pydeck,
                get_position=['longitude', 'latitude'],
                cell_size=100,
                extruded=True,
                pickable=False,
                elevation_scale=5
            )

            st.pydeck_chart(
                pdk.Deck(
                    layers=[grid_layer],
                    initial_view_state=view_state,
                    map_style=pdk.map_styles.DARK
                ),
                width=8000,
                height=700,
            )


    # ---- Navigation Map ---- #

    with st.container(border=True):
        
        st.subheader("Navigation Map")

        map_width = 8000
        map_heigh = 1050

        load_prediction_model()

        # layouts
        col1, col2 = st.columns([1,5])
        
        with col1:
            st.markdown("**Input Your Current Status:**")

            start_lat = st.number_input("Start Latitude", value=41.8781, format="%.6f")
            start_lon = st.number_input("Start Longitude", value=-87.6298, format="%.6f")
            end_lat = st.number_input("End Latitude", value=41.9000, format="%.6f")
            end_lon = st.number_input("End Longitude", value=-87.6500, format="%.6f")

            temperature = st.number_input("Temperature (Centigrade)", value=40.2, format="%.6f")
            humidity = st.number_input("Relative Humidity (Percentage %)", value=57.36, format="%.6f")

            hour = st.number_input("Hour (0-24: hours)", value=13, format="%d")
            weekday = st.number_input("Weekday (1-7: Mon-Sun)", value=5, format="%d")
            month = st.number_input("Month (1-12: JAN-DEC)", value=4, format="%d")

            get_path = st.button("Click to Get Your Safety Route!", type="primary")

            with st.container(border=True):
                st.markdown("First we predict the safety level of each zipcode district based on your inputs.")
                st.markdown("Then we provide you with an optimal route that takes both safety and distance into consideration.")
                st.markdown("We use Dijkstra algorithm to calculate the safey route.")
            
        with col2:
            st.markdown("It may take 5-10 minute to load if you run the website on your computer. This website is already deployed so you can access this link: http://18.118.103.225:8501/")

            prediction_result = prediction(hour=hour, weekday=weekday, month=month, temperature=temperature, humidity=humidity)

            chicago_zipcodes = load_chicago_zipcodes()
            chicago_zipcodes = assign_safety_levels(chicago_zipcodes, prediction_result)
            G = load_chicago_network()
            
            if G is None:
                st.error("fail to load chicago network.")
                return
            
            G_safe = modify_edge_weights_based_on_safety(G, chicago_zipcodes)  
            
            # Button: "Get your safety route"
            if get_path:
                start_point = (start_lat, start_lon)
                end_point = (end_lat, end_lon)
                
                # get the safety route
                path = calculate_safest_path(G_safe, start_point, end_point)
                
                if path:
                    m = create_map(chicago_zipcodes, G, path, start_point, end_point)
                    folium_static(m, width=map_width, height=map_heigh)                    
                    # path_length = sum(G[path[i]][path[i+1]][0].get('length', 0) for i in range(len(path)-1))
                else:
                    # display the map only without the path 
                    m = create_map(chicago_zipcodes, G, None, start_point, end_point)
                    folium_static(m, width=map_width, height=map_heigh)
            else:
                # display the default map
                m = create_map(chicago_zipcodes, None)
                folium_static(m, width=map_width, height=map_heigh)


if __name__ == "__main__":
    main()

