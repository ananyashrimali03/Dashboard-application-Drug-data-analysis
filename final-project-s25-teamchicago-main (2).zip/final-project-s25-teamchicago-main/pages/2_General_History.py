import streamlit as st
import pandas as pd
import numpy as np
import altair as alt

import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

st.set_page_config(page_title="General History", layout="wide")


# ------------------------------------------------------------------------------------------------------------------------------------
#Hero & Key 
# ------------------------------------------------------------------------------------------------------------------------------------
st.header("🗓️General History")

st.markdown("This dashboard provides a historical timeline of crime and weather trends in Chicago, allowing users to understand the data by date range, crime type, and weather patterns across 25 years.")




# ------------------------------------------------------------------------------------------------------------------------------------
#LOADING DATA 
# ------------------------------------------------------------------------------------------------------------------------------------

weather = pd.read_csv('data_clean/Chicago_Daily_Weatherdata.csv')
weather = weather.rename(columns={'MO':'month', 'DY':'day'})
weather['date_only'] = pd.to_datetime(weather[['YEAR', 'month', 'day']])

crimes = pd.read_csv("data_clean/AllCrimes_Daily.csv")
crimes['date_only'] = pd.to_datetime(crimes['date_only'])

ALL_CRIMES = "ALL CRIMES"




# Main Chart styling colors 
GRAY = "#bfbfbf"
ORANGE = "#ff8c42"

#Weather Chart Colors
RAIN_BLUE = "#0072b2"
WIND_PERI = "#56b4e9"
HUMID_YELLOW= "#e6bd56"
PRESS_PURPLE= "#cc79a7"


# ------------------------------------------------------------------------------------------------------------------------------------
#CRIME GRAPHS
# ------------------------------------------------------------------------------------------------------------------------------------

st.header("⚔️Crime Trends Over Time")


# Crime Filter Section
with st.expander("Filter for Crime Graphs & Timeline", expanded=True):
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Date Range")

        date_values = st.slider("", 
                    crimes["date_only"].min().date(), 
                    crimes["date_only"].max().date(),
                    (crimes["date_only"].min().date(), 
                    crimes["date_only"].max().date()))

    with col2:
        st.subheader("Crime Type")
        crime_list = np.append(ALL_CRIMES, crimes["primary_type"].sort_values().unique())
        crimes_selected = st.multiselect("Filter", crime_list, ["GAMBLING", "CRIMINAL SEXUAL ASSAULT", "STALKING", "HOMICIDE"])


    crimes_filtered = crimes[(crimes["date_only"].dt.date
                                >= date_values[0]) &
                            (crimes["date_only"].dt.date
                                <= date_values[1])]
    if ALL_CRIMES not in crimes_selected:
            crimes_filtered = crimes_filtered[crimes_filtered["primary_type"].isin(crimes_selected)]


# Group crime type by month across 25 years
crimes_filtered["year_month"] = crimes_filtered["date_only"].dt.to_period("M")
monthly_counts = crimes_filtered.groupby(["year_month", "primary_type"]).size().reset_index(name="count")
monthly_counts["year_month"] = monthly_counts["year_month"].dt.to_timestamp() # converted so Altair can properly plot the time

# Aggregate total count of crime type & monthly total --- sort by highest count
crime_totals = monthly_counts.groupby("primary_type")["count"].sum().reset_index(name="total_count")
monthly_counts = monthly_counts.merge(crime_totals, on="primary_type")



chart = alt.Chart(monthly_counts).mark_line(color="GREY").encode(
    x=alt.X("year_month:T", title="Month"),
    y=alt.Y("count:Q", title="Monthly Crime Count")
).properties(
    width=220,
    height=140
).facet(
    facet=alt.Facet("primary_type:N", 
                    title="", 
                    sort=alt.EncodingSortField(
                        field="total_count", 
                        order="descending")),
    columns=4
)

st.altair_chart(chart, use_container_width=True)

# ------------------------------------------------------------------------------------------------------------------------------------
#WEATHER GRAPHS
# ------------------------------------------------------------------------------------------------------------------------------------

st.header("☀️☔️❄️Weather Trends Over Time")


metric_options = {
    "Temperature (C)": "T2M",
    "Precipitation": "PRECTOTCORR",
    "Wind Speed": "WS10M",
    "Humidity": "RH2M",
    "Pressure": "PS"
}


with st.expander("Filters for Weather", expanded=True):

    col1, col2= st.columns(2)

    with col1:
        metric_charts = st.selectbox("Select a chart to display:", metric_options)  

    with col2:
        min_date = weather["date_only"].min().date()
        max_date = weather["date_only"].max().date()
        weather_date_values = st.slider(
            "Select Date Range",
            min_value=min_date,
            max_value=max_date,
            value=(min_date, max_date)
        )


# Filter weather data based on date range
filtered_data = weather[
    (weather["date_only"].dt.date >= weather_date_values[0]) &
    (weather["date_only"].dt.date <= weather_date_values[1])
]



# -------------------------------------------------------------------
# 🌡️Temperature
# -------------------------------------------------------------------
if metric_charts == "Temperature (C)":
    st.markdown("### 🌡️ Temperature (C)")

    if not filtered_data.empty:
        temp_trends = filtered_data[["date_only", "T2M"]].copy()
        temp_trends["month"] = temp_trends["date_only"].dt.to_period("M")
        temp_trends = temp_trends.groupby("month")["T2M"].mean().reset_index()
        temp_trends["month"] = temp_trends["month"].dt.to_timestamp()
        temp_trends["month_name"] = temp_trends["month"].dt.strftime('%b %Y')

        selection = alt.selection_point(encodings=['x'], on='click', clear='dblclick')

        base = alt.Chart(temp_trends).encode(
            x=alt.X('month:T', title=None, axis=alt.Axis(labelAngle=-45, format='%b %Y')),
            y=alt.Y('T2M:Q', title='Average Temperature (°C)'),
            tooltip=['month_name:N', alt.Tooltip('T2M:Q', format=".2f")],
            opacity=alt.condition(selection, alt.value(0.8), alt.value(0.4))
        ).properties(height=400)

        area = base.mark_area(opacity=0.2, color=GRAY)
        line = base.mark_line(color=ORANGE, strokeWidth=3)
        points = base.mark_circle(size=120, color=ORANGE, opacity=0.7)

        chart = alt.layer(area, line, points).add_params(selection)

        st.altair_chart(chart, use_container_width=True)
        st.write("Click a dot to highlight a month; double-click to reset.")
    else:
        st.info("No data available for the selected filters.")



# -------------------------------------------------------------------
# 🌧️PRECIPITATION
# -------------------------------------------------------------------
if metric_charts == "Precipitation":
    st.markdown("### 🌧️ Precipitation")

    if not filtered_data.empty:
        precip_trends = filtered_data[["date_only", "PRECTOTCORR"]].copy()
        precip_trends["month"] = precip_trends["date_only"].dt.to_period("M")
        precip_trends = precip_trends.groupby("month")["PRECTOTCORR"].mean().reset_index()
        precip_trends["month"] = precip_trends["month"].dt.to_timestamp()
        precip_trends["month_name"] = precip_trends["month"].dt.strftime('%b %Y')

        selection = alt.selection_point(encodings=['x'], on='click', clear='dblclick')

        base = alt.Chart(precip_trends).encode(
            x=alt.X('month:T', title=None, axis=alt.Axis(labelAngle=-45, format='%b %Y')),
            y=alt.Y('PRECTOTCORR:Q', title='Average Precipitation (Millimeters / Day)'),
            tooltip=['month_name:N', alt.Tooltip('PRECTOTCORR:Q', format=".2f")],
            opacity=alt.condition(selection, alt.value(0.8), alt.value(0.4))
        ).properties(height=400)

        area = base.mark_area(opacity=0.2, color=GRAY)
        line = base.mark_line(color=RAIN_BLUE, strokeWidth=3)
        points = base.mark_circle(size=120, color=RAIN_BLUE, opacity=0.7)

        chart = alt.layer(area, line, points).add_params(selection)

        st.altair_chart(chart, use_container_width=True)
        st.write("Click a dot to highlight a month; double-click to reset.")
    else:
        st.info("No data available for the selected filters.")





# -------------------------------------------------------------------
# 💨WIND SPEED
# -------------------------------------------------------------------
if metric_charts == "Wind Speed":
    st.markdown("### 💨 Wind Speed")

    if not filtered_data.empty:
        wind_trends = filtered_data[["date_only", "WS10M"]].copy()
        wind_trends["month"] = wind_trends["date_only"].dt.to_period("M")
        wind_trends = wind_trends.groupby("month")["WS10M"].mean().reset_index()
        wind_trends["month"] = wind_trends["month"].dt.to_timestamp()
        wind_trends["month_name"] = wind_trends["month"].dt.strftime('%b %Y')

        selection = alt.selection_point(encodings=['x'], on='click', clear='dblclick')

        base = alt.Chart(wind_trends).encode(
            x=alt.X('month:T', title=None, axis=alt.Axis(labelAngle=-45, format='%b %Y')),
            y=alt.Y('WS10M:Q', title='Average Wind Speed (meters / seconds)'),
            tooltip=['month_name:N', alt.Tooltip('WS10M:Q', format=".2f")],
            opacity=alt.condition(selection, alt.value(0.8), alt.value(0.4))
        ).properties(height=400)

        area = base.mark_area(opacity=0.2, color=GRAY)
        line = base.mark_line(color=WIND_PERI, strokeWidth=3)
        points = base.mark_circle(size=120, color=WIND_PERI, opacity=0.7)

        chart = alt.layer(area, line, points).add_params(selection)

        st.altair_chart(chart, use_container_width=True)
        st.write("Click a dot to highlight a month; double-click to reset.")
    else:
        st.info("No data available for the selected filters.")



# -------------------------------------------------------------------
# 💧Humidity
# -------------------------------------------------------------------
if metric_charts == "Humidity":
    st.markdown("### 💧 Humidity")

    if not filtered_data.empty:
        humidity_trends = filtered_data[["date_only", "RH2M"]].copy()
        humidity_trends["month"] = humidity_trends["date_only"].dt.to_period("M")
        humidity_trends = humidity_trends.groupby("month")["RH2M"].mean().reset_index()
        humidity_trends["month"] = humidity_trends["month"].dt.to_timestamp()
        humidity_trends["month_name"] = humidity_trends["month"].dt.strftime('%b %Y')

        selection = alt.selection_point(encodings=['x'], on='click', clear='dblclick')

        base = alt.Chart(humidity_trends).encode(
            x=alt.X('month:T', title=None, axis=alt.Axis(labelAngle=-45, format='%b %Y')),
            y=alt.Y('RH2M:Q', title='Average Relative Humidity (%)'),
            tooltip=['month_name:N', alt.Tooltip('RH2M:Q', format=".2f")],
            opacity=alt.condition(selection, alt.value(0.8), alt.value(0.4))
        ).properties(height=400)

        area = base.mark_area(opacity=0.2, color=GRAY)
        line = base.mark_line(color=HUMID_YELLOW, strokeWidth=3)
        points = base.mark_circle(size=120, color=HUMID_YELLOW, opacity=0.7)

        chart = alt.layer(area, line, points).add_params(selection)

        st.altair_chart(chart, use_container_width=True)
        st.write("Click a dot to highlight a month; double-click to reset.")
    else:
        st.info("No data available for the selected filters.")




# -------------------------------------------------------------------
# 🌀 Pressure
# -------------------------------------------------------------------
if metric_charts == "Pressure":
    st.markdown("### 🌀 Atmospheric Pressure")

    if not filtered_data.empty:
        pressure_trends = filtered_data[["date_only", "PS"]].copy()
        pressure_trends["month"] = pressure_trends["date_only"].dt.to_period("M")
        pressure_trends = pressure_trends.groupby("month")["PS"].mean().reset_index()
        pressure_trends["month"] = pressure_trends["month"].dt.to_timestamp()
        pressure_trends["month_name"] = pressure_trends["month"].dt.strftime('%b %Y')

        selection = alt.selection_point(encodings=['x'], on='click', clear='dblclick')

        base = alt.Chart(pressure_trends).encode(
            x=alt.X('month:T', title=None, axis=alt.Axis(labelAngle=-45, format='%b %Y')),
            y=alt.Y('PS:Q', title='Averageg Pressure at Surface Level (kPa)'),
            tooltip=['month_name:N', alt.Tooltip('PS:Q', format=".2f")],
            opacity=alt.condition(selection, alt.value(0.8), alt.value(0.4))
        ).properties(height=400)

        area = base.mark_area(opacity=0.2, color=GRAY)
        line = base.mark_line(color=PRESS_PURPLE, strokeWidth=3)
        points = base.mark_circle(size=120, color=PRESS_PURPLE, opacity=0.7)

        chart = alt.layer(area, line, points).add_params(selection)

        st.altair_chart(chart, use_container_width=True)
        st.write("Click a dot to highlight a month; double-click to reset.")
    else:
        st.info("No data available for the selected filters.")
