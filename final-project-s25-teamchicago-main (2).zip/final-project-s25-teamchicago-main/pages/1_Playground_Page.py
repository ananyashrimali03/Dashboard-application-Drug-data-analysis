import streamlit as st
import pandas as pd
import numpy as np
import altair as alt
from sodapy import Socrata

st.set_page_config(page_title="Chicago Crime Dashboard", layout="wide")

st.title("Chicago: Crime and Weather Dashboard")

# Fetch Data from Socrata API (asked chatgpt to add caching)
@st.cache_data(ttl=3600)
def fetch_crime_data():
    with st.spinner('Loading data...'):
        client = Socrata("data.cityofchicago.org", None)
        results = client.get("ijzp-q8t2", limit=100000, order="date DESC")
        df = pd.DataFrame.from_records(results)
        
        df['date'] = pd.to_datetime(df['date'])
        df['year'] = df['date'].dt.year
        df['month'] = df['date'].dt.month
        df['day_of_week'] = df['date'].dt.day_name()
        df['hour'] = df['date'].dt.hour
        
        return df

# Loading
data = fetch_crime_data()

# Filter Section
with st.expander("Filter Data", expanded=True):
    col1, col2, col3 = st.columns(3)

    with col1:
        st.subheader("Year")
        available_years = sorted(data['year'].unique(), reverse=True)
        selected_year = st.selectbox("Select year", available_years, index=0, label_visibility="collapsed")

    with col2:
        st.subheader("Crime Type")
        if 'primary_type' in data.columns:
            crime_types = ['All Types'] + sorted(data['primary_type'].unique().tolist())
            selected_crime = st.selectbox("Select crime type", crime_types, index=0, label_visibility="collapsed")
        else:
            selected_crime = "All Types"

    with col3:
        st.subheader("Time Period")
        time_periods = ["All Year", "Q1 (Jan-Mar)", "Q2 (Apr-Jun)", "Q3 (Jul-Sep)", "Q4 (Oct-Dec)"]
        selected_period = st.selectbox("Select time period", time_periods, index=0, label_visibility="collapsed")

# Filters
filtered_data = data[data['year'] == selected_year]

# Crime Type Filter
if selected_crime != "All Types" and 'primary_type' in data.columns:
    filtered_data = filtered_data[filtered_data['primary_type'] == selected_crime]

# Time Period Filter
if selected_period == "Q1 (Jan-Mar)":
    filtered_data = filtered_data[filtered_data['month'].isin([1, 2, 3])]
elif selected_period == "Q2 (Apr-Jun)":
    filtered_data = filtered_data[filtered_data['month'].isin([4, 5, 6])]
elif selected_period == "Q3 (Jul-Sep)":
    filtered_data = filtered_data[filtered_data['month'].isin([7, 8, 9])]
elif selected_period == "Q4 (Oct-Dec)":
    filtered_data = filtered_data[filtered_data['month'].isin([10, 11, 12])]

# Key Metrics Row
st.header("Key Metrics")
total_incidents = len(filtered_data)

col1, col2, col3, col4, col5 = st.columns(5)
col1.metric("Total Incidents", f"{total_incidents:,}")

if 'primary_type' in filtered_data.columns and not filtered_data.empty:
    most_common = filtered_data['primary_type'].value_counts().index[0]
    pct = (filtered_data['primary_type'].value_counts().iloc[0] / total_incidents) * 100
    col2.metric("Most Common Crime", most_common, f"{pct:.1f}% of total")
else:
    col2.metric("Most Common Crime", "N/A")

if 'day_of_week' in filtered_data.columns and not filtered_data.empty:
    busiest_day = filtered_data['day_of_week'].value_counts().index[0]
    pct = (filtered_data['day_of_week'].value_counts().iloc[0] / total_incidents) * 100
    col3.metric("Busiest Day", busiest_day, f"{pct:.1f}% of incidents")
else:
    col3.metric("Busiest Day", "N/A")

if 'hour' in filtered_data.columns and not filtered_data.empty:
    peak_hour = filtered_data['hour'].value_counts().index[0]
    hour_fmt = "12 AM" if peak_hour == 0 else "12 PM" if peak_hour == 12 else f"{peak_hour if peak_hour < 12 else peak_hour-12} {'AM' if peak_hour < 12 else 'PM'}"
    pct = (filtered_data['hour'].value_counts().iloc[0] / total_incidents) * 100
    col4.metric("Peak Hour", hour_fmt, f"{pct:.1f}% of incidents")
else:
    col4.metric("Peak Hour", "N/A")

# Season Metric

def get_season(month):
    if month in [12, 1, 2]:
        return "Winter"
    elif month in [3, 4, 5]:
        return "Spring"
    elif month in [6, 7, 8]:
        return "Summer"
    elif month in [9, 10, 11]:
        return "Fall"
    else:
        return "Unknown"

if not filtered_data.empty:
    # Season
    filtered_data = filtered_data.copy()
    filtered_data['season'] = filtered_data['month'].apply(get_season)
    peak_season = filtered_data['season'].value_counts().idxmax()
    peak_season_count = filtered_data['season'].value_counts().max()
    col5.metric("Peak Crime Season", peak_season, f"{peak_season_count} incidents")
else:
    col5.metric("Peak Crime Season", "N/A")

# Chart Dropdown
st.markdown("---")
st.subheader("Explore Crime Data Visualizations")
chart_options = [
    "Monthly Crime Trends",
    "Top Crime Locations",  
    "Crime by Day of Week",
    "Crime by Hour of Day",
    "Top 10 Crime Types",
    "Seasonal Crime Distribution"
]
selected_chart = st.selectbox("Select a chart to display:", chart_options)

# Colors
ORANGE = '#e89a49'
GRAY = '#9c9c9c'

if selected_chart == "Monthly Crime Trends":
    st.markdown("#### Monthly Crime Trends")
    if not filtered_data.empty:
        crime_trends = filtered_data.groupby(filtered_data['date'].dt.to_period('M')).size().reset_index(name='Count')
        crime_trends['date'] = crime_trends['date'].dt.to_timestamp()
        crime_trends['month_name'] = crime_trends['date'].dt.strftime('%b %Y')
        selection = alt.selection_point(encodings=['x'], on='click', clear='dblclick')
        base = alt.Chart(crime_trends).encode(
            x=alt.X('date:T', title=None, axis=alt.Axis(labelAngle=-45, format='%b %Y')),
            y=alt.Y('Count:Q', title='Number of Incidents'),
            tooltip=['month_name:N', 'Count:Q'],
            opacity=alt.condition(selection, alt.value(0.6), alt.value(0.4))
        ).properties(height=400)
        area = base.mark_area(opacity=0.2, color=GRAY)
        line = base.mark_line(color=ORANGE, strokeWidth=6)
        points = base.mark_circle(size=140, color=ORANGE, opacity=0.7)
        chart = alt.layer(area, line, points).add_params(selection)
        st.altair_chart(chart, use_container_width=True)
        st.write("Click a dot to highlight; double-click to clear.")
    else:
        st.info("No data available for the selected filters")

elif selected_chart == "Top Crime Locations":
    st.markdown("#### Top Crime Locations")
    if 'block' in filtered_data.columns and not filtered_data.empty:
        locations = filtered_data['block'].value_counts().head(10).reset_index()
        locations.columns = ['Location', 'Count']
        bar_select = alt.selection_point(fields=['Location'], on='click', clear='dblclick')
        location_chart = alt.Chart(locations).mark_bar().encode(
            y=alt.Y('Location:N', sort='-x', title=None),
            x=alt.X('Count:Q', title='Number of Incidents'),
            tooltip=['Location:N', 'Count:Q'],
            color=alt.condition(bar_select, alt.value(ORANGE), alt.value(GRAY))
        ).properties(height=400).add_params(bar_select)
        st.altair_chart(location_chart, use_container_width=True)
        st.write("Click a bar to highlight; double-click to clear.")
    else:
        st.info("No data available for this chart.")

elif selected_chart == "Crime by Day of Week":
    st.markdown("#### Crime by Day of Week")
    if not filtered_data.empty:
        day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        day_counts = filtered_data['day_of_week'].value_counts().reindex(day_order).fillna(0).reset_index()
        day_counts.columns = ['Day', 'Incidents']
        day_chart = alt.Chart(day_counts).mark_bar().encode(
            x=alt.X('Day:N', sort=day_order),
            y=alt.Y('Incidents:Q'),
            tooltip=['Day', 'Incidents'],
            color=alt.value(GRAY)
        ).properties(height=300)
        st.altair_chart(day_chart, use_container_width=True)
    else:
        st.info("No data available for this chart.")

elif selected_chart == "Crime by Hour of Day":
    st.markdown("#### Crime by Hour of Day")
    if not filtered_data.empty:
        hour_counts = filtered_data['hour'].value_counts().sort_index().reset_index()
        hour_counts.columns = ['Hour', 'Incidents']
        hour_chart = alt.Chart(hour_counts).mark_bar().encode(
            x=alt.X('Hour:O', title='Hour of Day'),
            y=alt.Y('Incidents:Q'),
            tooltip=['Hour', 'Incidents'],
            color=alt.value(GRAY)
        ).properties(height=300)
        st.altair_chart(hour_chart, use_container_width=True)
    else:
        st.info("No data available for this chart.")

elif selected_chart == "Top 10 Crime Types":
    st.markdown("#### Top 10 Crime Types")
    if 'primary_type' in filtered_data.columns and not filtered_data.empty:
        type_counts = filtered_data['primary_type'].value_counts().head(10).reset_index()
        type_counts.columns = ['Type', 'Incidents']
        type_chart = alt.Chart(type_counts).mark_bar().encode(
            x=alt.X('Type:N', sort='-y'),
            y=alt.Y('Incidents:Q'),
            tooltip=['Type', 'Incidents'],
            color=alt.value(GRAY)
        ).properties(height=300)
        st.altair_chart(type_chart, use_container_width=True)
    else:
        st.info("No data available for this chart.")

elif selected_chart == "Seasonal Crime Distribution":
    st.markdown("#### Seasonal Crime Distribution")
    if 'season' in filtered_data.columns and not filtered_data.empty:
        season_order = ['Winter', 'Spring', 'Summer', 'Fall']
        season_counts = filtered_data['season'].value_counts().reindex(season_order).fillna(0).reset_index()
        season_counts.columns = ['Season', 'Incidents']
        season_chart = alt.Chart(season_counts).mark_bar().encode(
            x=alt.X('Season:N', sort=season_order),
            y=alt.Y('Incidents:Q'),
            tooltip=['Season', 'Incidents'],
            color=alt.value(ORANGE)
        ).properties(height=300)
        st.altair_chart(season_chart, use_container_width=True)
    else:
        st.info("No data available for this chart.")
