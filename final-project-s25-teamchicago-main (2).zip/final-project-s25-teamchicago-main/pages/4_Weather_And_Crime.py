import streamlit as st
import pandas as pd
import numpy as np
import altair as alt
from datetime import timedelta

import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

ALL_CRIMES = "ALL CRIMES"

st.header("⛅ Crime & Weather")

st.markdown("This dashboard illustrates the correlation between crime and weather trends in Chicago, empowering users to understand how seasonality and weather events shape crime rates across 25 years.")



st.subheader('Seasonality')

# Loading data
weather = pd.read_csv('data_clean/Chicago_Daily_Weatherdata.csv')
weather = weather.rename(columns={'MO':'month', 'DY':'day'})
weather['date_only'] = pd.to_datetime(weather[['YEAR', 'month', 'day']])

crimes = pd.read_csv("data_clean/AllCrimes_Daily.csv")
crimes['date_only'] = pd.to_datetime(crimes['date_only'])

# Filtering elements
col1, col2 = st.columns(2)

with col1:
    date_values = st.slider("Filter by Year", 
                crimes["date_only"].min().date(), 
                crimes["date_only"].max().date(),
                (crimes["date_only"].min().date(), 
                crimes["date_only"].max().date()))

with col2:
    crime_list = np.append(crimes["primary_type"].sort_values().unique(), ALL_CRIMES)
    crimes_selected = st.multiselect("Filter by crimes types:", crime_list, "THEFT")


crimes_filtered = crimes[(crimes["date_only"].dt.date
                           >= date_values[0]) &
                          (crimes["date_only"].dt.date
                           <= date_values[1])]
if ALL_CRIMES not in crimes_selected:
    crimes_filtered = crimes_filtered[crimes_filtered["primary_type"].isin(crimes_selected)]
crimes_per_day = crimes_filtered.groupby('date_only', as_index=False)['id'].sum()

# Setting up graph
crime_color = '#808588'
crime_chart = alt.Chart(crimes_per_day).mark_line(color=crime_color, opacity=0.8).encode(
    x = alt.X("date_only:T", title = "Date"),
    y = alt.Y("id").axis(title="Total crimes per day", titleColor=crime_color)
)

weather_filtered = weather[(weather["date_only"].dt.date
                           >= date_values[0]) &
                          (weather["date_only"].dt.date
                           <= date_values[1])]

weather_color = '#EC6D10'
weather_chart = alt.Chart(weather_filtered).mark_line(color=weather_color, opacity=0.7).encode(
    x = alt.X("date_only:T", title = "Date"),
    y = alt.Y("T2M", scale=alt.Scale(domain=[-30, 100])).axis(title="Temperature in C", titleColor=weather_color)
    
)

plot = alt.layer(weather_chart, crime_chart).resolve_scale(
    y='independent'
)

st.altair_chart(plot, use_container_width=True, theme=None)



st.subheader('Closer look 🔎')
st.text('This section focuses on hourly crime rates in comparison to temperature, humidity and wind speed. It showcases a finer-grain comparison between weather and criminal activity.')

crimes_hourly = pd.read_csv('data_clean/AllCrimes_2025_20250410.csv')
weather_hourly = pd.read_csv('data_clean/Chicago_Weatherdata.csv')

crimes_hourly['date'] = pd.to_datetime(crimes_hourly['Date'], format="%m/%d/%Y %I:%M:%S %p")
crimes_hourly['nearest_hour'] = crimes_hourly['date'].dt.floor('H')

weather_hourly = weather_hourly.rename(columns={'MO':'month', 'DY':'day', 'HR':'hour'})
weather_hourly['nearest_hour'] = pd.to_datetime(weather_hourly[['YEAR', 'month', 'day', 'hour']])



# Define the time boundaries
data_min = max(crimes_hourly["nearest_hour"].min().date(), weather_hourly["nearest_hour"].min().date())
data_max = min(crimes_hourly["nearest_hour"].max().date(), weather_hourly["nearest_hour"].max().date())

# Filtering elements
col1, col2 = st.columns(2)

with col1:
    date_values = st.slider("Filter by Year", 
                data_min, 
                data_max,
                ((data_max - timedelta(days=7)), 
                data_max))

with col2:
    crime_list = np.append(crimes_hourly["Primary Type"].sort_values().unique(), ALL_CRIMES)
    crimes_selected_hourly = st.multiselect("Filter by crimes types:", crime_list, ALL_CRIMES)


crimes_hourly_filtered = crimes_hourly[(crimes_hourly["nearest_hour"].dt.date
                           >= date_values[0]) &
                          (crimes_hourly["nearest_hour"].dt.date
                           <= date_values[1])]

if ALL_CRIMES not in crimes_selected_hourly:
    crimes_hourly_filtered = crimes_hourly_filtered[crimes_hourly_filtered["Primary Type"].isin(crimes_selected_hourly)]

crimes_per_hour = crimes_hourly_filtered.groupby(['nearest_hour'], as_index=False)['ID'].count()


# Checkboxes
col1, col2, col3 = st.columns(3)
with col1:
    temp = st.checkbox("Temperature", value=True)
with col2:
    hmdt = st.checkbox("Humidity", value=True)
with col3:
    wind = st.checkbox("Wind speed", value=True)

offset = 0

# Setting up graph
crime_hourly_chart = alt.Chart(crimes_per_hour).mark_bar(color=crime_color, opacity=0.8).encode(
    x = alt.X("nearest_hour:T", title = "Date"),
    y = alt.Y("ID").axis(title="Total crimes per day", titleColor=crime_color)
)

weather_hourly_filtered = weather_hourly[(weather_hourly["nearest_hour"].dt.date
                           >= date_values[0]) &
                          (weather_hourly["nearest_hour"].dt.date
                           <= date_values[1])]

hourly_temp, hourly_humidity, hourly_wind = alt.Chart(), alt.Chart(), alt.Chart()
if temp:
    hourly_temp = alt.Chart(weather_hourly_filtered).mark_line(color=weather_color, opacity=0.7).encode(
        x = alt.X("nearest_hour:T", title = "Date"),
        y = alt.Y("TEMP").axis(title="Temperature in C", titleColor=weather_color, labelColor = weather_color, orient='right')    
    )
    offset += 50

if hmdt:
    hmdt_color = "#0A2472"
    hourly_humidity = alt.Chart(weather_hourly_filtered).mark_line(color=hmdt_color, opacity=0.6).encode(
        x = alt.X("nearest_hour:T", title = "Date"),
        y = alt.Y("HMDT").axis(title="Humidity", titleColor=hmdt_color, labelColor=hmdt_color, offset = offset, orient='right')
    )
    offset += 50

if wind:
    wind_color = "#466D1D"
    hourly_wind = alt.Chart(weather_hourly_filtered).mark_line(color=wind_color, opacity=0.6).encode(
        x = alt.X("nearest_hour:T", title = "Date"),
        y = alt.Y("WND_SPD").axis(title="Windspeed", titleColor=wind_color, labelColor=wind_color, offset = offset, orient='right')
    )


final_plot = crime_hourly_chart

if temp:
    final_plot = alt.layer(final_plot, hourly_temp).resolve_scale(
        y='independent'
    )

if hmdt:
    final_plot = alt.layer(final_plot, hourly_humidity).resolve_scale(
        y='independent'
    )

if wind:
    final_plot = alt.layer(final_plot, hourly_wind).resolve_scale(
        y='independent'
    )

st.altair_chart(final_plot, use_container_width=True, theme=None)
