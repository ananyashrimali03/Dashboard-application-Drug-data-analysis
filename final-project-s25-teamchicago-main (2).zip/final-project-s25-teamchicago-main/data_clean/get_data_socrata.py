from sodapy import Socrata
import pandas as pd

client = Socrata("data.cityofchicago.org", None)
results = client.get("ijzp-q8t2", limit=100000, order="date DESC")
df = pd.DataFrame.from_records(results)
print(df.head(10))

