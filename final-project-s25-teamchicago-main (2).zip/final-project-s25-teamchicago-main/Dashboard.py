# streamlit run Dashboard.py

import streamlit as st
import pandas as pd
import numpy as np
import altair as alt

import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
st.set_page_config(page_title="Chicago Crime Dashboard", layout="wide")

st.header("Team Chicago")

st.markdown("""
## 📊 Welcome to the Chicago Crime & Weather Dashboard

This dashboard was created to help make sense of crime patterns in Chicago over the last 25 years.  
Using data from the Chicago Police Department’s CLEAR system, we’ve mapped over 8 million reported incidents between 2001 and March 2025.  
Each report includes key details like the time, location, and type of crime.

We’ve also incorporated historical weather data such as temperature, wind, and precipitation to explore how environmental conditions may influence when and where crimes occur.

Our goal is to help users observe general trends, assess neighborhood safety, and better understand the relationship between weather and crime.  
Feel free to explore and interact with the dashboard! 
            
**How to navigate the dashboard:**

**🛝 Playground**: 
        Start here to play with the data to gain a basic understanding of theft, crime locations, and weather patterns.

**🗓️ General History**: 
        Explore high-level timelines help you explore how crime types and environmental patterns have evolved across 25 years.

**🗺️ Crime Maps**: 
        Our visual guide illuminates the geography of crime in Chicago. 
        Visualize which districts face the highest risks and analyze crime density while highlighting safer routes home.

**⛅ Crime & Weather**: 
        Explore our core question on how weather and crime intersect. 
        Discover how temperature, wind, and precipitation correlate with various crime types. 

""")
