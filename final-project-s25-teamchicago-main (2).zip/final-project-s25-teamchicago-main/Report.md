# Final Project Report

**Our webapp now has been deployed at: http://18.118.103.225:8501!** (will not expire until this June)

**Video URL**: https://youtu.be/n5SN8jQGWzs

## Abstract

Our project aims to help people stay safe and make informed decisions for a more secure life in Chicago by analyzing long-term crime data alongside weather conditions (i.e., relative humidity, temperature at 2m). We choose to use crime incident reports from the Chicago Police Department’s CLEAR system (2002 - 2025) to investigate how crime patterns vary across time, location, and environmental contexts. The dataset includes more than 8 million records of reported crimes, providing detailed information on crime type, time of occurrence, geographic location (longitude and latitude), and setting (i.e., street, residence).

Our core data science question focuses on identifying which areas in Chicago pose the highest risk for pedestrians after midnight. We believe this is very helpful for people who are visiting Chicago for the first time. (i.e., international students, travellers, etc.) To answer this, we examine how crime prevalence shifts across districts, times of day, seasons, and weather conditions. By integrating historical weather data, we finish a prediction model and further explore the correlation between them.

The primary outcome of this work is an introductory dashboard incorporated with 4 interactive pages that are designed to make these insights accessible to the general public users. This involves pages where users can interactively explore different crime patterns and correlations in Chicago. Further, it also provides proven safe routes that take both crime risk and route efficiency into consideration. This system could be especially valuable for foreign travelers and international students unfamiliar with Chicago’s safety landscape, helping them navigate the city with greater confidence and awareness. 



## Introduction
Our project investigates long-term crime patterns in the city of Chicago using publicly available data from the Chicago Police Department’s CLEAR system. This dataset includes over 8 million reported incidents from January 1, 2001, to March 11, 2025, and contains detailed information such as the type of crime, location, time of occurrence, and whether an arrest was made. By analyzing this data, our team aism to identify where and when specific crimes are most likely to occur and determine how crime trends have shifted over the past 25 years.

In addition to analyzing crime data, we explore how environmental conditions may impact crime rates by integrating a supplementary dataset containing historical weather information. Our combined dataset allows for comparisons between temperature, precipitation humidity, wind speed, pressure, and the frequency or nature of reported crimes. Previous research has suggested that higher temperatures are associated with increased rates of violent crime. We aim to test these patterns across multiple weather variables and timeframes to determine if such relationships are present in Chicago’s data.

The primary data science question our team aimed to answer is: Which areas in Chicago pose the highest risk for pedestrians after midnight? This question also leads us to investigate:
* How crime prevalence differs across Chicago districts.
* How time of day affects specific crime rates.
* How crime trends have evolved over 25 years.
* How seasonal changes and weather conditions influence crime.
* Which crime types are most common during specific times and weather conditions.

Our final deliverable is an interactive dashboard that allows users to filter and explore these datasets through maps, graphs, and statistical visualizations. This includes a general data exploration playground, long-term visualizations of crime and weather, a crime map highlighting high-risk districts and locations, proven safe routes from destination to destination, and an in-depth weather and crime analysis page that explores correlations between crime patterns and environmental conditions. Our team believes this tool can support and use realiable data to inform Chicago public safety efforts and make long-term patterns in crime more accessible and understandable for a wider audience.


## Related Work


Previous research has shown strong correlations between weather conditions (i.e., temperature, humidity, etc.) and crime rates. Field and his team [1] conducted a studies demonstrating that higher temperaltures tend to increase violent crime rates. Besides, Mares and Moffett [2] further explored the relationship between precipitation and violent crime patterns. Inspired by these findings, our project incorporates weather-related features such as temperature and relative humidity into the crime prediction model to predict the safety level for each zipcode region.

In terms of navigation and path planning, several related works have considered safety routing in urban environments. Sharon and her team [3] proposed a route planning method that integrates safety-critical considerations. This encourage us to do exploration on implementing a navigation system that take both safety and distance as consideration. For visualization, tools like Folium and Mapbox are helpful to render the map [4]. In our project, we further enhance the visualization by leveraging PyDeck that is effective at rendering 3D heatmaps to intuitively represent crime intensity under different weather conditions.

## Methods

### Playground Page
The Playground Page was developed using Streamlit, Python, and the Socrata API to create an 
interactive data exploration. 

**Caching:** 

The City of Chicago’s open data portal was connected and implemented data caching to reduce API load. We use st.cache_data to optimize.

**Layout:**

**Title:**

The layout is defined using st.set_page_config() for the wide view. The primary title is done using st.title().

**Filters:**

Once the dataset is loaded, the key features like year, month and hour are extracted using pandas. The months are also classifies into seasons for analysis. The filters section uses st.selectbox() for the dropdown filters and organized using st.column. The filter minimizing and maximizing uses st.expander and st. subheader for heading display. 

**Metric and summary statistics:**

This section uses st.metric() to display Key Metrics calculated from the filtered dataset. It displays:
1. Total Incidents
2. Most Common Crime
3. Busiest day
4. Peak Hour
5. Peak Hour
6. Peak Crime Season

The get_season() function assigns each month to a season category.

**Charts (using altair):**

For charts we selected to show using dropdown selection option for display. The dropdown again uuses  st.selectbox. 

There are 6 chart options in total:
1. Monthly Crime Trends: uses mark_area, mark_line, and mark_circle with alt.layer() and alt.selection_point() for interactivity. 

2. Top Crime Locations: This is a bar chart using block data, with alt.selection_point() for click interactions.

3. Crime by Day of Week: Ordered bar chart showing incident counts by weekday.

4. Crime by Hour of Day: Displays 24-hour distribution using histogram-style bar chart.

5. Top 10 Crime Types: A simple bar chart ranking the top crime categories.

6. Seasonal Crime Distribution: Aggregated bar chart grouped by season.

Each chart is wrapped in conditionals and done using st.altair_chart() with container width enabled.
### General History Page


#### Interface and user input

The General History page uses st.set_page_config() to define the page title and apply a wide layout for better visualization spacing. Page sections are labeled using st.header() and st.markdown().
A st.slider() component is used to filter both crime and weather data by date range. Crime types are selectable using st.multiselect(), allowing multiple categories to be viewed at once. For weather metrics, a st.selectbox() enables users to choose one variable at a time.
To organize the interface, st.columns() structures the layout into multiple columns, and st.expander() is used to group filters into collapsible sections, keeping the dashboard clean and easy to navigate.

#### Data Handling (Pandas)

pd.read_csv() is used which reads pre-cleaned crime and weather datasets from CSV files.
pd.to_datetime() & .dt.to_period() which Converts and formats date columns for consistent temporal grouping and plotting
.groupby() + .mean() / .size() is used extensively for temporal aggregation of crimes and environmental conditions.
.copy() is used to avoid SettingWithCopyWarning while modifying filtered subsets

#### Visualizations (Altair)

alt.Chart() is the base for all visualizations including line, area, and point charts.
.mark_line(), .mark_area(), .mark_circle() combines area fill, line trends, and circular data points for rich visual storytelling
.encode(): Binds data columns to visual encodings (X, Y, color, tooltip, opacity)
.facet(): Used in crime charts to show mini-plots by crime type sorted by total count.
.layer(): Overlays multiple chart types (area, line, points) into one cohesive visualization
.selection_point(): Adds interactivity by allowing users to highlight specific months in weather data

#### Performance & User Experience Enhancements


warnings.simplefilter(): Suppresses pandas FutureWarning for cleaner Streamlit console output.
st.info(): Provides contextual user feedback if no data is found for the selected filters.


### Crime Maps Page

This page is a Chicago Safety Navigation System that involves 2 maps. 
#### Crime Counts 3D Heatmap

This is a 3D heatmap that visualizes history crime distribution based on weather inputs. The positional information (longitude and latitude) is processed into a grid system. Each grid cell contains a column representing the number of crime instances in that area. The columns are also color-coded to reflect crime intensity.

The visualization is built with PyDeck. Users can hold Ctrl to adjust the viewing perspective.

#### Navigation Map

First, the system predicts the safety level for each district based on the provided inputs: weekday, month, temperature, and relative humidity. The Safety Level is defined as follows:

$$
\text{Safety Level} = 10 - \text{percentile}\left( \text{qcut}(\text{Predicted Crimes}) \right)
$$


The model is trained using the Random Forest algorithm. Both the encoder and the trained model file are stored in a public AWS S3 bucket, making them accessible to everyone:

- Model: https://bucket-ml-ids.s3.amazonaws.com/crime_model.pkl
- Encoder: https://bucket-ml-ids.s3.amazonaws.com/zipcode_encoder.pkl

We then provide a "Safety Route" feature that considers both distance and safety level. Specifically, we apply the Dijkstra algorithm, but modify the edge weight to:

$$
\text{Edge Weight} = \text{distance} \times (11 - \text{Safety Level})
$$

This way, we provide an optimal route that balances between the shortest distance and overall safety. Users can click the "Get Your Safety Route!" button to generate their customized optimal route.

This page is built with Mapbox. We initially attempted to implement it using raw Streamlit with Folium, but that approach only offered basic rendering capabilities which did not meet our expectations. 

Since we are using a free public Mapbox token (owner: Yuchen Wang), the first-time load may take up to 10 minutes. We implemented caching strategies that cache the rendered map for up to 2 hours that ensures the subsequent accesses faster.

Zipcode boundary data is provided by: https://data.cityofchicago.org/api/geospatial/unjd-c2ca?method=export&format=GeoJSON".

### Weather & Crime Page

The Weather & Crime page was built using altair and pandas. It is made of two charts that illustrate two time scales: daily and hourly. 

The weather data comes from the NASA Power Project API: https://power.larc.nasa.gov. The weather data is extracted using Chicago’s coordinates following the method from the Chicago Weather Dataset methodology : https://www.kaggle.com/code/curiel/data-mining-weather-chicago/notebook

#### Seasonality Chart
The first chart shows the daily number of crimes with the daily temperature. The date ranges from 2001 to 2025. 

The user can filter data using the time range tool and can select crime to visualize using a multi select box. 



#### Hourly Chart
The second chart shows a close-up to how crime rates vary in smaller time windows. The weather and crime counts are aggregated hourly. The weather is described hourly by three metrics: average temperature, average humidity and average wind speed. 

The user can filter data using the time range tool and can select crimes to visualize using a multi select box. They can also show/hide the three different weather metrics using checkboxes.


## Results


### Playground Page

![](./images/final_report/playg.png)


The Playground Page is where users can interactively explore different crime patterns and correlations in Chicago. It’s designed to be flexible and intuitive, allowing users to crop and cut the data by different filters and instantly view updated visualizations.

**Filter section:**

The filter section can be minimized and maximized. The dataset can be filtered using three dropdown options:

1. Year: It can be chosen to display which year to see and visualize
2. Crime type: The data can be filtered based on the crime type to show visualizations specific to that particular crime type.
3. Time period: The visualizations can be further divided into quarters for clearer understanding. 

The filters help narrow down the focus and it personalizes as per how the user wants to see and what area they want to focus in viewing the dataset. 

**Key Metrics:**

The key metric shows the important highlights based on the filters made by the user. And shows key summary stats:

1. Total Incidents based on the selected filters

2. Most Common Crime Type

3. Busiest Day of the Week

4. Peak Hour of the day

5. Peak Crime Season

These quick stats give a quick idea of the filtered data and helps the users get oriented quickly.

**Charts:**

Further down, there’s a dropdown menu that lets users explore different types of charts, each showing a different angle of the crime data:

1. Monthly Crime Trends: shows how crimes fluctuate month to month. It’s a great way to spot seasonal spikes or drops. The user can also select the dots (month) to highlight it for their reference.

2. Top Crime Locations: This chart highlights which neighborhoods or regions report the most incidents. The user can also select the bar to highlight it for their reference.

3. Crime by Day of Week: This chart lets the user see how crime changes over the course of a week. We noticed weekends tend to be more active.

4. Crime by Hour of Day: This chart breaks the crime data down by the hour, showing patterns like late-night spikes around midnight.

5. Top 10 Crime Types: This chart lists the most frequent crime categories based on the filters selected by the user.

6. Seasonal Crime Distribution: This chart groups crimes by season (Winter, Spring, Summer, Fall) to show seasonal shifts in activity.

This page is easy to explore and navigate, it uses simple intuitive features to quickly adept to the filter system. It shows important data, like the most common crime, using simple ways. It can be used for public awareness as well as policy exploration. This page acts as a starting point to further explore into the crime conditions and contributes into our in depth weather and environmental correlation with urban safety.
### General History Page

![](./images/final_report/History.png)

To ease into the correlation between crime and environmental factors in Chicago, the General History page offers an interactive visualization of 25 years of crime and weather data. Viewing these timelines side by side allows users to quickly spot unusual spikes and long-term trends, which allows them to gain a better understanding of when and why crime might fluctuate.

For example, several crime types such as robbery and assault show annually consistent spikes in February. This odd recurring pattern across several crime types raises questions whether it is the result of February winter conditions or structural features within the Chicago’s data system. 

The crime visualization also illustrates more drastic fluctuations in crime patterns such as the criminal sexual assault’s drastic drop in 2020, which is likely a direct result from the COVID-19 pandemic.

The weather section of the dashboard visualizes five key environmental metrics: temperature, precipitation, wind speed, humidity, and surface pressure. Each chart presents monthly averages over time, with interactive tooltips and clickable highlights for further data exploration. Further, seasonality is especially clear in temperature and humidity charts, where the consistency of monthly cycles is seen year after year.

Although crime and weather data are visualized separately, placing them within the same page allows users to begin investigating potential relationships between environmental change and public safety. 

### Crime Maps Page

![](./images/final_report/crime_map_page.png)

This page could be helpful for foreign travelers or international students in planning their routes and finding safer paths to their destinations. For example, a newcomer to Chicago who is unfamiliar with the local safety conditions could use our system to navigate the city while avoiding areas with higher crime rates or potential street harassment. Similarly, an international student who has just arrived in Chicago and is looking for the safest and most efficient way to reach their campus could benefit from our navigation map.

### Weather & Crime Page

![](./images/final_report/C&W.png)

The Weather & Crime pages easily illustrate correlations that exist between temperature and crime rates. It allows users to identify common trends in crime rates according to seasons and weather patterns. 

The Seasonality graph offers two main insights:
Crime has decreased steadily in the past 25 years. 
There is a strong correlation between temperature and crime. Seasons associated with higher weather also observe higher crime rates and vice-versa. 

The Close-up chart featuring hourly weather yields more mixed results. We observe that daily fluctuation in temperature is also correlated with crime: most crimes are committed around noon, where the temperature is the highest. However, the graph doesn’t give convincing evidence that more crimes are committed on days with high temperatures. 

## Discussion

The dashboard is designed to support interactive and self-guided exploration of Chicago's crime data for a range of audiences, from public safety professionals and researchers to local residents and visitors who are unfamiliar with the city, like students from outside the city. The filters and key metrics can quickly help getting an idea about the scenario and trends. The quick graph visualizations can help understand which areas to avoid during what time or season can really help the people who are not familiar with the city. The exploratory page makes it easy to learn patterns across time, location, and crime type without needing any training. 

Our navigation system helps users better understand how crime risk is distributed across different zipcode region of Chicago. The 3D heatmap allows people to easily spot regions with higher crime intensity by the given weather conditions. One piece of informal feedback we received was from one of our friends who was an international student. His main concern wasn’t about finding the shortest route, but the safest one, even if that meant taking a longer way. He consider that a system like ours would have been very helpful at the time that he first came there.

## Future Work

We can calculate a more accurate safety path based on block-level region evaluation instead of zipcode-level. To achieve this, we may need to collect block-level boundary data of Chicago. futher, our current safe route system is designed for driving. We can incorporate useful sidewalk data to make it capable of navigating pedestrians.

## Reference

[1] S. Field, “The effect of temperature on crime,” British Journal of Criminology, vol. 32, no. 3, pp. 340–351, 1992.

[2] D. Mares and K. W. Moffett, “Climate change and crime: Monthly temperature and precipitation forecasts of violent crime rates,” Environment and Behavior, vol. 48, no. 2, pp. 296–318, 2016.

[3] S. J. Zhi, E. Learned-Miller, and P. J. Keller, “SafeRoute: Learning to Navigate Streets Safely in an Urban Environment,” in Proceedings of the 2019 IEEE Winter Conference on Applications of Computer Vision (WACV), Waikoloa Village, HI, USA, 2019, pp. 1606–1614, doi: 10.1109/WACV.2019.00175.

[4] Streamlit, Folium, and Mapbox documentation and open-source examples, available online: https://streamlit.io/, https://python-visualization.github.io/folium/, https://docs.mapbox.com/ (accessed Apr. 2025).

## Appendix

### How to run

#### Mac OS or Windows (Vscode)
1. Download `Docker Desktop` from `https://www.docker.com/get-started/`
2. Install `Dev Container` extension in your Vscode
3. `cd` to the project root directory and run
   ```
   docker-compose build
   ```
4. Press `Ctrl + Shift + P`. Type `> Dev Containers: Reopen in Container`. Press `Enter`. (Or you can just click the pop-ups to reopen in container)
5. If you are going to install more python packages, make sure to involve them into `requirements.txt`. For example you want to install `Scikit-learn` and `Pytest`, the `requirements.txt` should look like this:
    ```
    scikit-learn
    pytest
    ```

#### Linux
1. Install Docker Engine
2. Quick commands:
    ``` Bash
    docker compose up -d --build # build the image and start the container
    docker exec -it datascience-dev bash # get into the container
    docker compose down # stop the container
    ```


### Project Structure

- `.devcontainer/`: For VScode Dev Container
- `data_analysis/`: Exploratory Data Analysis scripts
  - `exploratory_data_analysis.ipynb`: The EDA script for step_2 (Sketches)
- `data_clean/`: Scripts to clean data, train models, etc.
- `images/`: Images for docs (i.e., Proposal.md, README.md)
- `model/`: Trained models. (i.e., serve for prediction purpose)
- `pages/`: Streamlit pages
  - `1_Playground_Page.py`: Dashboard showing basic information of the two datasets.
  - `2_General_History.py`: General History with timeline
    - Trends what's coming down & coming up
    - A area chart with the frequency of the most frequent crimes
  - `3_Crime_Maps.py`
    - A prediction system to predict the system level based on past crime data
    - A navigation system that can provide the safer path based on current predicted safety levels.
  - `4_Weather_And_Crime.py`
    - Detailed filters
    - Season maps - crime by winter/spring/summer/fall
    - Pattern of prominent crime locations during weather?
        - Ie: snowing a lot = lots of robberies in shadyside 
    - Trends of particular crimes - top 10 crimes
- `tests/`: Unit testing scripts
- `utils/`
  - `path.py`: get specified path from the root directory of this project.
  - `prediction.py`: predict the safety level based on the given inputs (for page3).
  - `data.py`: get dataframe/geodataframe of the cleaned data.
  - `navigation_map.py`: key components of the Page_3.
- `Dashboard.py`: a dashboard page. The Starting point to run the project.
- `docker-compose.yml`: docker-compose.yml
- `Dockerfile`: Dockerfile
- `requirement.txt`: list of python packages to set the container